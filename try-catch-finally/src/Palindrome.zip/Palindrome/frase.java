package Palindrome;


import java.io.PrintWriter;
import java.io.FileNotFoundException;
import java.util.*;


public class frase {

	 public static void main(String[] args) {
	      
		 Scanner teclado=new Scanner(System.in);
		 
	   
	       
	       PrintWriter salida=null;

	       try { 
	    	   salida=new PrintWriter("Palindromo.txt");
	    	   System.out.println("Intoduce una frase");
	    	   String Palabra = teclado.next();   
	    	   String invertida = "";
	    	 	
	           String PalabraSinEspacios = Palabra.replace(" ", "");    
	           
	           StringBuffer StringF = new StringBuffer(PalabraSinEspacios);  
	            
	           StringF = StringF.reverse(); 
	           for (int indice = Palabra.length() - 1; indice >= 0; indice--) {
	   		
	   			invertida += Palabra.charAt(indice);
	   		}
	            
	           if(PalabraSinEspacios.equalsIgnoreCase(StringF.toString())){   
	                
	               
	               salida.print(Palabra+" al reves "+invertida+" es palindromo "); 
	           }
	           else{
	        	   salida.print(Palabra+" al reves "+invertida+" no es palindromo "); 
	           }
	         
	           
	       salida.flush();
	       }
	       catch(FileNotFoundException e) {
	    	   System.out.println(e.getMessage());
	    	   
	       }
	       finally {
	    	   salida.close();
	       }
	   }
	}

	

